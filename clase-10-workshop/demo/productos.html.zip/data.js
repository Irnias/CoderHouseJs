const products = [{
    "id" : 1,
    "name" : "Playstation",
    "description" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec suscipit tempus hendrerit.",
    "image" : "https://picsum.photos/300/200",
    "price" : 100,
    "available" : true,
    tags : ["consola", "sony", "gaming"]
},{
    "id" : 2,
    "name" : "Iphone",
    "description" : "Phasellus vitae pretium mauris. Fusce sed metus nec dui sagittis venenatis id sed nisl. Nam sem est, euismod vitae eleifend id, semper at arcu.",
    "image" : "https://picsum.photos/300/200",
    "price" : 200,
    "available" : true,
    tags : ["phone", "apple"]
},{
    "id" : 3,
    "name" : "Chromecast",
    "description" : "Proin condimentum tincidunt massa vitae condimentum. Nam eleifend sed quam eget tempus.",
    "image" : "https://picsum.photos/300/200",
    "price" : 300,
    "available" : false,
    tags : ["tv", "google"]
}];

const selectedProducts = [];