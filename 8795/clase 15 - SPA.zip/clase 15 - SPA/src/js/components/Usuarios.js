
let text = '';
misUsuarios.forEach(e => { text += `, ${e}` })
const userComponent = `Los usuarios habilitados son: ${text}`